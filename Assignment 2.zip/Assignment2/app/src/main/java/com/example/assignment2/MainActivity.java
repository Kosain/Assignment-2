package com.example.assignment2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    private Button btnUser, btnProfileView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUser = findViewById(R.id.btn_userSettings);
        btnProfileView = findViewById(R.id.buttonToProfile);

        loadFragment(new UserSettingsFragment());

        btnUser.setOnClickListener(v -> loadFragment(new UserSettingsFragment()));

        btnProfileView.setOnClickListener(v -> loadFragment(new ProfileViewFragment()));
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
