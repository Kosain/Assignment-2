package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileViewFragment extends Fragment {

    private TextView usernameTextView, emailTextView, passwordTextView, colorTextView;
    private SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile_view, container, false);

        // Initialize TextViews
        usernameTextView = view.findViewById(R.id.P_username);
        emailTextView = view.findViewById(R.id.P_email);
        passwordTextView = view.findViewById(R.id.P_password);
        colorTextView = view.findViewById(R.id.P_color); // Color TextView

        // Get SharedPreferences instance
        sharedPreferences = getActivity().getSharedPreferences(UserSettingsFragment.PREF_NAME, Context.MODE_PRIVATE);

        // Load and display saved preferences
        loadPreferences();

        return view;
    }

    private void loadPreferences() {
        // Retrieve saved preferences from SharedPreferences
        String username = sharedPreferences.getString(UserSettingsFragment.KEY_USERNAME, "N/A");
        String email = sharedPreferences.getString(UserSettingsFragment.KEY_EMAIL, "N/A");
        String password = sharedPreferences.getString(UserSettingsFragment.KEY_PASSWORD, "N/A");
        String color = sharedPreferences.getString(UserSettingsFragment.KEY_COLOR, "N/A");

        // Set the TextViews with the retrieved values
        usernameTextView.setText("Username: " + username);
        emailTextView.setText("Email: " + email);
        passwordTextView.setText("Password: " + password);
        colorTextView.setText("Color Theme: " + color); // Display color preference
    }
}
