package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class UserSettingsFragment extends Fragment {

    private EditText usernameEditText, emailEditText, passwordEditText, colorEditText;
    private Button saveButton, resetButton;

    private SharedPreferences sharedPreferences;

    public static final String PREF_NAME = "UserPreferences";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_COLOR = "color"; // New key for color

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_settings_, container, false);

        usernameEditText = view.findViewById(R.id.username);
        emailEditText = view.findViewById(R.id.email);
        passwordEditText = view.findViewById(R.id.password);
        colorEditText = view.findViewById(R.id.colors);
        saveButton = view.findViewById(R.id.savepref);
        resetButton = view.findViewById(R.id.resetpref);

        sharedPreferences = getActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        loadPreferences();

        saveButton.setOnClickListener(v -> savePreferences());

        resetButton.setOnClickListener(v -> resetPreferences());

        return view;
    }

    private void loadPreferences() {
        String username = sharedPreferences.getString(KEY_USERNAME, "");
        String email = sharedPreferences.getString(KEY_EMAIL, "");
        String password = sharedPreferences.getString(KEY_PASSWORD, "");
        String color = sharedPreferences.getString(KEY_COLOR, "");

        usernameEditText.setText(username);
        emailEditText.setText(email);
        passwordEditText.setText(password);
        colorEditText.setText(color);
    }

    private void savePreferences() {
        String username = usernameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String color = colorEditText.getText().toString().trim(); // Get color value

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || color.isEmpty()) {
            Toast.makeText(getActivity(), "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(getActivity(), "Invalid email format", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_USERNAME, username);
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_PASSWORD, password);
        editor.putString(KEY_COLOR, color); // Save color value
        editor.apply();

        Toast.makeText(getActivity(), "Preferences Saved", Toast.LENGTH_SHORT).show();
    }

    private void resetPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        Toast.makeText(getActivity(), "Preferences Reset", Toast.LENGTH_SHORT).show();
        loadPreferences();
    }
}
